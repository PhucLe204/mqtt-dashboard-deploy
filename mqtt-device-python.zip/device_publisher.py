#!/usr/bin/env python3
"""Simulated device: publish sensor data to the local EC2 Mosquitto broker.

This demonstration runs on the EC2 host. It does not expose MQTT/1883 to
public networks. A real remote sensor needs authenticated, encrypted MQTT.
"""
import argparse
import json
import random
import sys
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt


def main():
    parser = argparse.ArgumentParser(description="Gia lap thiet bi gui nhiet do/do am qua MQTT")
    parser.add_argument("--host", default="127.0.0.1", help="Dia chi MQTT Broker; mac dinh localhost EC2")
    parser.add_argument("--port", type=int, default=1883)
    parser.add_argument("--topic", default="device/data")
    parser.add_argument("--interval", type=float, default=2, help="Giay giua 2 ban tin")
    parser.add_argument("--count", type=int, default=15, help="So ban tin; 0 de chay lien tuc")
    args = parser.parse_args()
    if args.count < 0 or args.interval <= 0 or not 1 <= args.port <= 65535:
        parser.error("--count phai >= 0, --interval > 0 va port hop le")

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="device-simulator-python")
    try:
        client.connect(args.host, args.port, keepalive=30)
        client.loop_start()
        print(f"Device MQTT Client | broker={args.host}:{args.port} | topic={args.topic}", flush=True)
        n = 0
        while args.count == 0 or n < args.count:
            n += 1
            temperature = round(29 + random.uniform(-3, 5), 1)
            humidity = round(62 + random.uniform(-10, 10), 1)
            # Use the same field names as the ASP.NET Core dashboard expects.
            payload = json.dumps({"temp": temperature, "hum": humidity}, separators=(",", ":"))
            info = client.publish(args.topic, payload, qos=1, retain=False)
            info.wait_for_publish(timeout=10)
            if not info.is_published():
                raise RuntimeError("Khong xac nhan duoc ban tin MQTT")
            now = datetime.now().astimezone().strftime("%H:%M:%S")
            print(f"[{now}] PUB #{n:02d} {args.topic} {payload}", flush=True)
            if args.count == 0 or n < args.count:
                time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nDa dung mo phong.")
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"LOI: {exc}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()
        client.loop_stop()
    print("Hoan thanh gui du lieu MQTT.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
