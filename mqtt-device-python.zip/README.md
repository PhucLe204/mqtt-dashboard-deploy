# Device MQTT Client bằng Python — Demo đồ án

Đây là **thiết bị giả lập chạy ngay trên AWS EC2**, không phải một thiết bị vật lý gửi từ Internet. Gửi bản tin JSON `{"temp":29.5,"hum":62.0}` vào topic `device/data` để kiểm thử chuỗi:

Python publisher → Mosquitto (localhost:1883) → ASP.NET Core MQTTnet subscriber → SignalR → View.

## Cài và chạy trên Ubuntu 24.04

```bash
sudo apt install -y python3-venv
python3 -m venv ~/mqtt-device/.venv
~/mqtt-device/.venv/bin/pip install -r ~/mqtt-device/requirements.txt
~/mqtt-device/.venv/bin/python ~/mqtt-device/device_publisher.py
```

Mặc định gửi **15 bản tin**, mỗi bản tin cách nhau 2 giây. Chạy 10 bản tin:

```bash
~/mqtt-device/.venv/bin/python ~/mqtt-device/device_publisher.py --count 10
```

Chạy liên tục (dừng bằng Ctrl+C):

```bash
~/mqtt-device/.venv/bin/python ~/mqtt-device/device_publisher.py --count 0
```

Không mở public port 1883 để chạy demo này. Nếu muốn chuyển Python client ra máy Windows hay ESP32 độc lập, cần cấu hình listener MQTT ngoài EC2 với xác thực, TLS (ví dụ 8883), Security Group giới hạn nguồn và cập nhật tham số kết nối. Không hardcode mật khẩu vào repository public.
