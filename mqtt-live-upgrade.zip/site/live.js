(() => {
  'use strict';
  let socket = null;
  let retryTimer = null;
  let closed = false;
  let retryMs = 1500;
  const dashboard = () => window.MQTTDashboard;

  function connect() {
    if (closed) return;
    const scheme = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    try {
      socket = new WebSocket(`${scheme}//${window.location.host}/mqtt-ws`);
    } catch (error) {
      retry();
      return;
    }
    socket.addEventListener('open', () => { retryMs = 1500; });
    socket.addEventListener('message', (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'status') {
          dashboard()?.setBrokerConnected(Boolean(data.mqttConnected));
        } else if (data.type === 'message' && data.topic === 'device/data') {
          dashboard()?.receive(data.topic, data.payload);
        }
      } catch (error) { console.warn('MQTT message invalid:', error); }
    });
    socket.addEventListener('close', () => {
      dashboard()?.setBrokerConnected(false);
      retry();
    });
    socket.addEventListener('error', () => {
      // The close handler performs reconnection.
    });
  }

  function retry() {
    if (closed || retryTimer) return;
    retryTimer = window.setTimeout(() => {
      retryTimer = null;
      connect();
    }, retryMs);
    retryMs = Math.min(10000, Math.round(retryMs * 1.5));
  }

  window.addEventListener('pagehide', () => {
    closed = true;
    if (retryTimer) window.clearTimeout(retryTimer);
    if (socket) socket.close();
  });
  connect();
})();
