#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
if [[ $(id -u) -ne 0 ]]; then echo "Run as: sudo bash $0"; exit 1; fi
if [[ ! -e /var/www/mqtt-dashboard/index.html ]]; then
  echo "Website /var/www/mqtt-dashboard/index.html not found"; exit 1
fi
if ! systemctl is-active --quiet mosquitto; then
  echo "Mosquitto is not running. Start: sudo systemctl start mosquitto"; exit 1
fi

printf '\n[1/5] Install Node.js/npm...\n'
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y nodejs npm

printf '\n[2/5] Install read-only MQTT bridge...\n'
install -d -o ubuntu -g ubuntu -m 755 /opt/mqtt-dashboard-bridge
install -o ubuntu -g ubuntu -m 644 "$DIR/bridge/server.js" /opt/mqtt-dashboard-bridge/server.js
install -o ubuntu -g ubuntu -m 644 "$DIR/bridge/package.json" /opt/mqtt-dashboard-bridge/package.json
runuser -u ubuntu -- sh -c 'cd /opt/mqtt-dashboard-bridge && npm install --omit=dev --no-audit --no-fund'

printf '\n[3/5] Install front-end integration...\n'
install -m 644 "$DIR/site/app.js" /var/www/mqtt-dashboard/app.js
install -m 644 "$DIR/site/live.js" /var/www/mqtt-dashboard/live.js
install -m 644 "$DIR/site/index.html" /var/www/mqtt-dashboard/index.html

printf '\n[4/5] Configure systemd...\n'
cat >/etc/systemd/system/mqtt-dashboard-bridge.service <<'SERVICE'
[Unit]
Description=MQTT Dashboard read-only WebSocket bridge
After=network.target mosquitto.service
Wants=mosquitto.service
[Service]
Type=simple
User=ubuntu
Group=ubuntu
WorkingDirectory=/opt/mqtt-dashboard-bridge
ExecStart=/usr/bin/node /opt/mqtt-dashboard-bridge/server.js
Environment=NODE_ENV=production
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now mqtt-dashboard-bridge.service
systemctl restart mqtt-dashboard-bridge.service

printf '\n[5/5] Configure nginx with local WebSocket reverse proxy...\n'
cat >/etc/nginx/sites-available/mqtt-dashboard <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    root /var/www/mqtt-dashboard;
    index index.html;

    location = /mqtt-ws {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 65s;
        proxy_send_timeout 65s;
        proxy_buffering off;
    }
    location / {
        try_files $uri $uri/ =404;
    }
}
NGINX
ln -sfn /etc/nginx/sites-available/mqtt-dashboard /etc/nginx/sites-enabled/mqtt-dashboard
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
printf '\nDONE. Health status:\n'
curl -fsS http://127.0.0.1:3001/health || true
printf '\n\nWebsite: http://13.211.234.188\n'
