# MQTT Dashboard Live Upgrade

This package is an add-on to the existing static MQTT Dashboard deployment. It keeps the Mosquitto broker on `127.0.0.1:1883` and adds a **read-only** Node.js MQTT-to-WebSocket bridge on `127.0.0.1:3001`. Nginx proxies `/mqtt-ws` to Node.js; browsers cannot publish MQTT commands through this service.

Install on EC2 Ubuntu 24.04 (with Mosquitto and Nginx already installed):

1. Upload `mqtt-live-upgrade.zip` to your public GitHub repo `PhucLe204/mqtt-dashboard-deploy`.
2. In EC2 Instance Connect:

```bash
cd ~/mqtt-dashboard-deploy && git pull
unzip -o mqtt-live-upgrade.zip -d ~/mqtt-live-upgrade
sudo bash ~/mqtt-live-upgrade/install.sh
```

The installer updates existing files under `/var/www/mqtt-dashboard`, installs Node.js/npm and MQTT/WS packages, creates `/opt/mqtt-dashboard-bridge`, installs a systemd service and Nginx reverse proxy for `/mqtt-ws`.

Test:

```bash
curl http://127.0.0.1:3001/health
sudo systemctl status mqtt-dashboard-bridge --no-pager
mosquitto_pub -h 127.0.0.1 -t device/data -m '{"temp":30,"hum":60}'
```

Browser: open `http://13.211.234.188` and refresh with Ctrl+F5. WebSocket status should become 'Đã kết nối MQTT'.

**Security:** This is a public telemetry demo over unencrypted HTTP/WebSocket. Do not send secret/sensitive telemetry or expose port 1883/3001 publicly. Configure HTTPS, authentication and authorization before a real-world deployment. GitHub repository and front-end files must never include passwords or `.pem` keys.
