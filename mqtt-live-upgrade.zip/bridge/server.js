/* MQTT-only subscriber, read-only websocket clients; bind to 127.0.0.1. */
'use strict';
const http = require('http');
const mqtt = require('mqtt');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = 3001;
const TOPIC = 'device/data';
let mqttConnected = false;
const server = http.createServer((req, res) => {
  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ bridge: 'ok', mqttConnected, topic: TOPIC }));
    return;
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocketServer({ server, path: '/mqtt-ws', perMessageDeflate: false, maxPayload: 4096 });
function broadcast(data) {
  const text = JSON.stringify(data);
  for (const browser of wss.clients) {
    if (browser.readyState === WebSocket.OPEN && browser.bufferedAmount < 1024 * 1024) {
      browser.send(text);
    }
  }
}
function updateStatus(connected) {
  mqttConnected = connected;
  broadcast({ type: 'status', mqttConnected });
}
wss.on('connection', (browser) => {
  browser.send(JSON.stringify({ type: 'status', mqttConnected }));
  browser.on('error', (error) => console.warn('WS:', error.message));
});

const client = mqtt.connect('mqtt://127.0.0.1:1883', {
  reconnectPeriod: 3000,
  connectTimeout: 10000,
  clientId: 'dashboard_bridge_' + process.pid,
});
client.on('connect', () => {
  client.subscribe(TOPIC, { qos: 0 }, (error) => {
    if (error) {
      console.error('MQTT subscribe failed:', error.message);
      updateStatus(false);
    } else {
      console.log('MQTT subscribed:', TOPIC);
      updateStatus(true);
    }
  });
});
client.on('message', (topic, payload) => {
  if (topic !== TOPIC || payload.length > 4096) return;
  const raw = payload.toString('utf8');
  broadcast({ type: 'message', topic, payload: raw });
});
client.on('close', () => updateStatus(false));
client.on('offline', () => updateStatus(false));
client.on('error', (error) => console.error('MQTT:', error.message));
server.listen(PORT, '127.0.0.1', () => {
  console.log(`MQTT bridge listening on 127.0.0.1:${PORT} (not public)`);
});
