#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo'; exit 1; fi
CONF=/etc/nginx/sites-available/mqtt-dashboard
BACKUP=/etc/nginx/sites-available/mqtt-dashboard.before-aspnet.bak
if [[ ! -f "$BACKUP" ]]; then echo 'No backup available'; exit 1; fi
cp "$BACKUP" "$CONF"
nginx -t
systemctl reload nginx
systemctl disable --now mqtt-aspnet || true
systemctl enable --now mqtt-dashboard-bridge || true
echo 'Previous Node.js Dashboard and Nginx config restored.'
