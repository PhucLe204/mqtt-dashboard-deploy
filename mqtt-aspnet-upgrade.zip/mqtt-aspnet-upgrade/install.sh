#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Use: sudo bash ~/mqtt-aspnet-upgrade/install.sh'; exit 1; fi
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/src/MqttDashboard.Web/MqttDashboard.Web.csproj"
CONF=/etc/nginx/sites-available/mqtt-dashboard
BACKUP=/etc/nginx/sites-available/mqtt-dashboard.before-aspnet.bak

if ! systemctl is-active --quiet mosquitto; then
  echo 'ERROR: Mosquitto is not running. Run: sudo systemctl start mosquitto'
  exit 1
fi
echo '[1/5] Install official .NET 10 SDK (Ubuntu 24.04)...'
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y dotnet-sdk-10.0 curl

echo '[2/5] Restore and publish ASP.NET Core + MQTTnet...'
# t3.micro has 1 GiB RAM; a small local swap avoids build OOM failures.
if [[ "$(awk '/MemTotal:/ {print $2}' /proc/meminfo)" -lt 1600000 ]] && [[ -z "$(swapon --noheadings 2>/dev/null)" ]]; then
  echo 'Low RAM detected: adding 1 GiB swap in existing EBS volume...'
  if [[ ! -f /swapfile ]]; then fallocate -l 1G /swapfile; fi
  chmod 600 /swapfile
  mkswap /swapfile >/dev/null
  swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >>/etc/fstab
fi
dotnet publish "$APP" -c Release -m:1 -o /opt/mqtt-aspnet/current
chmod -R a+rX /opt/mqtt-aspnet/current

echo '[3/5] Start ASP.NET Core on localhost:5000...'
cat >/etc/systemd/system/mqtt-aspnet.service <<'SERVICE'
[Unit]
Description=ASP.NET Core MQTTnet SignalR Dashboard
After=network.target mosquitto.service
Wants=mosquitto.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/mqtt-aspnet/current
ExecStart=/usr/bin/dotnet /opt/mqtt-aspnet/current/MqttDashboard.Web.dll
Environment=ASPNETCORE_URLS=http://127.0.0.1:5000
Environment=ASPNETCORE_ENVIRONMENT=Production
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now mqtt-aspnet
systemctl restart mqtt-aspnet

# Verify the new service BEFORE switching from the working Node.js website.
for i in $(seq 1 20); do
  if curl -fsS --max-time 2 http://127.0.0.1:5000/health >/dev/null; then
    break
  fi
  sleep 1
done
if ! curl -fsS --max-time 3 http://127.0.0.1:5000/health; then
  echo 'ASP.NET start failed. Old Nginx site left unchanged.'
  journalctl -u mqtt-aspnet -n 50 --no-pager
  exit 1
fi

echo '\n[4/5] Switch Nginx to ASP.NET Core / SignalR...'
if [[ -e "$CONF" && ! -e "$BACKUP" ]]; then cp "$CONF" "$BACKUP"; fi
cat >"$CONF" <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }
}
NGINX
ln -sfn "$CONF" /etc/nginx/sites-enabled/mqtt-dashboard
rm -f /etc/nginx/sites-enabled/default
if ! nginx -t; then
  if [[ -f "$BACKUP" ]]; then cp "$BACKUP" "$CONF"; fi
  nginx -t || true
  echo 'Nginx configuration failed; backup restored. Check manually.'
  exit 1
fi
systemctl reload nginx
if ! curl -fsS --max-time 3 http://127.0.0.1/health; then
  if [[ -f "$BACKUP" ]]; then cp "$BACKUP" "$CONF"; nginx -t && systemctl reload nginx; fi
  echo 'Nginx health failed. Restored previous site.'
  exit 1
fi

echo '\n[5/5] Disable old Node.js bridge (no longer needed)...'
systemctl disable --now mqtt-dashboard-bridge.service 2>/dev/null || true
echo
echo 'OK: ASP.NET Core + MQTTnet + SignalR active.'
echo 'Visit: http://13.211.234.188'
echo 'Health:'
curl -fsS http://127.0.0.1/health
echo
echo 'Test: mosquitto_pub -h 127.0.0.1 -t device/data -m '\''{"temp":32,"hum":65}'\'''
