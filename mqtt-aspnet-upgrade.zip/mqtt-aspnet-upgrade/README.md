# MQTT Dashboard - ASP.NET Core + SignalR + MQTTnet

Implements the teacher's architecture:

`Device MQTT Publish -> Mosquitto Broker -> ASP.NET Core MQTTnet Subscriber -> SignalR Hub -> Razor View`.

## Project

- `src/MqttDashboard.Web/Controllers/HomeController.cs`: MVC controller
- `src/MqttDashboard.Web/Views/Home/Index.cshtml`: UI View
- `src/MqttDashboard.Web/Services/MqttSubscriberService.cs`: MQTT subscriber/background service, 3s reconnect loop
- `src/MqttDashboard.Web/Hubs/SensorHub.cs`: server-to-browser SignalR Hub
- `src/MqttDashboard.Web/wwwroot`: existing CSS/JS design, SignalR integration
- `install.sh`: installer for Ubuntu 24.04 EC2, keeps old Nginx until new app passes health checks
- `rollback.sh`: restore previous Node.js implementation if needed

## Installation on the already-configured AWS EC2

1. Upload this ZIP to the existing public repo `PhucLe204/mqtt-dashboard-deploy` (do not remove old files).
2. EC2 terminal:
   ```bash
   cd ~/mqtt-dashboard-deploy && git pull
   unzip -o mqtt-aspnet-upgrade.zip -d ~
   sudo bash ~/mqtt-aspnet-upgrade/install.sh
   ```
3. Check:
   ```bash
   sudo systemctl status mqtt-aspnet --no-pager
   curl -fsS http://127.0.0.1:5000/health
   curl -fsS http://127.0.0.1/health
   mosquitto_pub -h 127.0.0.1 -t device/data -m '{"temp":32,"hum":65}'
   ```
4. Open http://13.211.234.188 and check temperature 32 / humidity 65.

**Security:** TCP 5000 / 1883 remain loopback-only, no need to open AWS Security Groups for them. Nginx exposes only HTTP 80. For production, add TLS, authentication/authorization to the dashboard and configure MQTT TLS/authentication before accepting external devices. Do not publish private credentials to GitHub.

**System note:** on 1-GiB t3.micro instances, the install script creates 1 GiB swap on the existing EBS volume if none is configured, to reduce build out-of-memory errors.

**Limitations:** history is only stored in the browser session, not a persistent database. Demo mode still works. Official SignalR browser client uses a pinned jsDelivr CDN reference, which requires client-side Internet access. The EC2 must be able to download the MQTTnet NuGet package during first install.

**Rollback:**
```bash
sudo bash ~/mqtt-aspnet-upgrade/rollback.sh
```
