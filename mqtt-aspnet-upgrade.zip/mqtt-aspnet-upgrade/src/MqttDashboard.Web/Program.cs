using MqttDashboard.Web.Hubs;
using MqttDashboard.Web.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSignalR();
builder.Services.AddSingleton<MqttConnectionState>();
builder.Services.AddHostedService<MqttSubscriberService>();

var app = builder.Build();
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseRouting();

// Intentionally read-only for the classroom demo. Never expose secrets here.
app.MapGet("/health", (MqttConnectionState mqtt) =>
    Results.Json(new { app = "aspnet-core", mqttConnected = mqtt.Connected, topic = "device/data" }));
app.MapHub<SensorHub>("/sensorHub");
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
app.Run();
