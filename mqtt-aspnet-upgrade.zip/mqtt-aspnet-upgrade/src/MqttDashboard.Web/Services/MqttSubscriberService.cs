using Microsoft.AspNetCore.SignalR;
using MQTTnet;
using MQTTnet.Client;
using MqttDashboard.Web.Hubs;

namespace MqttDashboard.Web.Services;

/// <summary>
/// Device -> Mosquitto -> MQTTnet subscriber -> SignalR Hub -> Razor View.
/// Broker stays on loopback. Only Nginx ports 80/443 are public.
/// </summary>
public sealed class MqttSubscriberService : BackgroundService
{
    private readonly IHubContext<SensorHub> _hub;
    private readonly MqttConnectionState _state;
    private readonly IConfiguration _config;
    private readonly ILogger<MqttSubscriberService> _logger;

    public MqttSubscriberService(
        IHubContext<SensorHub> hub,
        MqttConnectionState state,
        IConfiguration config,
        ILogger<MqttSubscriberService> logger)
    {
        _hub = hub;
        _state = state;
        _config = config;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var host = _config["Mqtt:Host"] ?? "127.0.0.1";
        var port = _config.GetValue<int>("Mqtt:Port", 1883);
        var topic = _config["Mqtt:Topic"] ?? "device/data";
        var factory = new MqttClientFactory();

        while (!stoppingToken.IsCancellationRequested)
        {
            using var client = factory.CreateMqttClient();

            client.ApplicationMessageReceivedAsync += async e =>
            {
                if (e.ApplicationMessage.Topic != topic) return;
                string payload = e.ApplicationMessage.ConvertPayloadToString() ?? string.Empty;
                if (payload.Length > 4096)
                {
                    _logger.LogWarning("Ignored oversized message on topic {Topic}", topic);
                    return;
                }
                await _hub.Clients.All.SendAsync("SensorMessage", new
                {
                    topic,
                    payload
                });
            };

            client.DisconnectedAsync += async e =>
            {
                _state.Connected = false;
                await _hub.Clients.All.SendAsync("MqttStatus", false);
            };

            try
            {
                var options = new MqttClientOptionsBuilder()
                    .WithTcpServer(host, port)
                    .WithClientId("aspnet_mqtt_dashboard_" + Guid.NewGuid().ToString("N"))
                    .Build();

                await client.ConnectAsync(options, stoppingToken);
                var subscribeOptions = factory.CreateSubscribeOptionsBuilder()
                    .WithTopicFilter(topic)
                    .Build();
                await client.SubscribeAsync(subscribeOptions, stoppingToken);
                _state.Connected = true;
                _logger.LogInformation("Subscribed to {Topic} via Mosquitto {Host}:{Port}", topic, host, port);
                await _hub.Clients.All.SendAsync("MqttStatus", true, stoppingToken);

                while (client.IsConnected && !stoppingToken.IsCancellationRequested)
                    await Task.Delay(1000, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception exception)
            {
                _logger.LogWarning(exception, "MQTT connection failed, retrying");
            }
            finally
            {
                _state.Connected = false;
                try { await _hub.Clients.All.SendAsync("MqttStatus", false); }
                catch (Exception ex) { _logger.LogDebug(ex, "Unable to announce offline state"); }
            }

            try { await Task.Delay(TimeSpan.FromSeconds(3), stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }
}
