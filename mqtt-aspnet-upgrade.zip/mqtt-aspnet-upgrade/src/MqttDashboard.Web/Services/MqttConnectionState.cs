namespace MqttDashboard.Web.Services;

public sealed class MqttConnectionState
{
    private volatile bool _connected;
    public bool Connected
    {
        get => _connected;
        set => _connected = value;
    }
}
