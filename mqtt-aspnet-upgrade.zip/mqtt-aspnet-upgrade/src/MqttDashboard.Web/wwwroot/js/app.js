'use strict';
(() => {
  const el = (id) => document.getElementById(id);
  const chart = el('telemetryChart');
  const ctx = chart.getContext('2d');
  const temperatureValue = el('temperatureValue');
  const humidityValue = el('humidityValue');
  const messageCount = el('messageCount');
  const lastUpdated = el('lastUpdated');
  const connectionState = el('connectionState');
  const connectionText = el('connectionText');
  const notice = el('notice');
  const noticeText = el('noticeText');
  const historyCount = el('historyCount');
  const chartEmpty = el('chartEmpty');
  const chartSource = el('chartSource');
  const rows = el('messageRows');
  const demoButton = el('demoButton');
  let samples = [];
  let count = 0;
  let demoTimer = null;
  let syntheticSeen = false;
  let mqttConnected = false;
  const formatTime = (date) => date.toLocaleTimeString('vi-VN', { hour12: false });

  function state(kind, label) {
    connectionState.className = `status-chip ${kind}`;
    connectionText.textContent = label;
  }

  function sensorValues(payload) {
    let temperature = null, humidity = null;
    if (typeof payload === 'number') temperature = payload;
    else {
      const text = typeof payload === 'string' ? payload : JSON.stringify(payload);
      try {
        const object = typeof payload === 'object' && payload !== null ? payload : JSON.parse(text);
        const t = object.temperature ?? object.temp ?? object.t;
        const h = object.humidity ?? object.hum ?? object.h;
        if (t !== undefined && Number.isFinite(Number(t))) temperature = Number(t);
        if (h !== undefined && Number.isFinite(Number(h))) humidity = Number(h);
      } catch {
        const t = text.match(/(?:temp(?:erature)?|nhiệt\s*độ)\s*[:=]\s*(-?\d+(?:\.\d+)?)/i);
        const h = text.match(/(?:humidity|hum|độ\s*ẩm)\s*[:=]\s*(-?\d+(?:\.\d+)?)/i);
        if (t) temperature = Number(t[1]);
        if (h) humidity = Number(h[1]);
      }
    }
    return {
      temperature: Number.isFinite(temperature) ? temperature : null,
      humidity: Number.isFinite(humidity) ? humidity : null
    };
  }

  function renderChart() {
    const bounds = chart.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    chart.width = Math.round(bounds.width * dpr);
    chart.height = Math.round(bounds.height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = bounds.width, h = bounds.height;
    ctx.clearRect(0, 0, w, h);
    const left = 42, right = 15, top = 12, bottom = 27;
    const cw = w - left - right, ch = h - top - bottom;
    const values = samples.map((x) => x.value);
    const low = values.length ? Math.floor((Math.min(...values) - 5) / 10) * 10 : 0;
    const high = values.length ? Math.ceil((Math.max(...values) + 5) / 10) * 10 : 50;
    const yMin = Math.min(low, high - 10), yMax = Math.max(high, low + 10);
    ctx.font = '11px system-ui, sans-serif';
    ctx.fillStyle = '#8096b0';
    ctx.strokeStyle = '#2a3a50';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = top + ch * i / 4;
      ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(w - right, y); ctx.stroke();
      const label = (yMax - (yMax - yMin) * i / 4).toFixed(0);
      ctx.textAlign = 'right'; ctx.fillText(label, left - 10, y + 4);
    }
    if (!values.length) return;
    const x = (i) => left + cw * i / Math.max(1, values.length - 1);
    const y = (v) => top + (yMax - v) / (yMax - yMin) * ch;
    const gradient = ctx.createLinearGradient(0, top, 0, h);
    gradient.addColorStop(0, 'rgba(79, 211, 233, 0.24)');
    gradient.addColorStop(1, 'rgba(79, 211, 233, 0)');
    ctx.beginPath(); values.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)));
    ctx.lineTo(x(values.length - 1), top + ch); ctx.lineTo(x(0), top + ch); ctx.closePath();
    ctx.fillStyle = gradient; ctx.fill();
    ctx.beginPath(); values.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)));
    ctx.strokeStyle = '#5bdde9'; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
    const px = x(values.length - 1), py = y(values[values.length - 1]);
    ctx.beginPath(); ctx.arc(px, py, 4.5, 0, Math.PI * 2); ctx.fillStyle = '#5bdde9'; ctx.fill();
    ctx.textAlign = 'left'; ctx.fillStyle = '#8195ad';
    ctx.fillText(samples[0].time, left, h - 6);
    ctx.textAlign = 'right'; ctx.fillText(samples[samples.length - 1].time, w - right, h - 6);
  }

  function insertMessage(time, topic, payload, source) {
    const empty = el('emptyHistory');
    if (empty) empty.remove();
    const row = document.createElement('tr');
    const timeCell = document.createElement('td');
    const topicCell = document.createElement('td');
    const payloadCell = document.createElement('td');
    const sourceCell = document.createElement('td');
    const topicText = document.createElement('span');
    const badge = document.createElement('span');
    timeCell.textContent = time; topicText.textContent = topic; topicText.className = 'topic';
    payloadCell.textContent = typeof payload === 'string' ? payload : JSON.stringify(payload);
    badge.textContent = source === 'demo' ? 'Mô phỏng' : 'MQTT';
    badge.className = `source-badge ${source === 'demo' ? 'demo' : ''}`;
    topicCell.appendChild(topicText); sourceCell.appendChild(badge);
    row.append(timeCell, topicCell, payloadCell, sourceCell);
    rows.prepend(row);
    while (rows.children.length > 50) rows.lastElementChild.remove();
  }

  function receive(topic, payload, source = 'mqtt') {
    const time = formatTime(new Date());
    count++;
    messageCount.textContent = String(count);
    historyCount.textContent = `${count} bản tin`;
    lastUpdated.textContent = time;
    const parsed = sensorValues(payload);
    if (parsed.temperature !== null) {
      temperatureValue.textContent = parsed.temperature.toFixed(1);
      samples.push({ value: parsed.temperature, time });
      if (samples.length > 30) samples.shift();
      chartEmpty.hidden = true;
      el('chartSource').textContent = `Nguồn dữ liệu: ${source === 'demo' ? 'mô phỏng' : 'MQTT'}`;
      el('chartSource').previousElementSibling.textContent = `${samples.length} mẫu dữ liệu`;
      renderChart();
    }
    if (parsed.humidity !== null) humidityValue.textContent = parsed.humidity.toFixed(1);
    if (source === 'demo') {
      syntheticSeen = true;
      notice.classList.add('demo');
      noticeText.innerHTML = '<strong>Chế độ thử nghiệm:</strong> Các giá trị đang hiển thị là dữ liệu mô phỏng, không phải từ thiết bị IoT thật.';
      state('demo', 'Dữ liệu mô phỏng');
    } else if (!demoTimer) {
      notice.classList.remove('demo');
      noticeText.innerHTML = '<strong>Đã nhận bản tin MQTT.</strong> Kiểm tra kết nối Broker và dữ liệu cảm biến để xác nhận nguồn.';
      state('live', 'Đã nhận bản tin');
    }
    insertMessage(time, topic, payload, source);
  }

  function demoSend() {
    const temp = 28 + Math.sin(Date.now() / 7000) * 5 + (Math.random() - 0.5) * 1.6;
    const hum = 62 + Math.sin(Date.now() / 11000) * 10 + (Math.random() - 0.5) * 3;
    receive('device/data', { temperature: Number(temp.toFixed(1)), humidity: Number(hum.toFixed(1)) }, 'demo');
  }

  function setBrokerConnected(connected) {
    mqttConnected = Boolean(connected);
    if (demoTimer !== null) return;
    if (mqttConnected) {
      state('live', 'Đã kết nối MQTT');
      notice.classList.remove('demo');
      noticeText.innerHTML = '<strong>MQTT trực tuyến.</strong> Đang nhận dữ liệu từ topic device/data khi có bản tin mới.';
    } else {
      state('offline', 'Chưa kết nối MQTT');
      if (!syntheticSeen) {
        notice.classList.remove('demo');
        noticeText.innerHTML = '<strong>Đang chờ kết nối MQTT.</strong> Kiểm tra Mosquitto và dịch vụ ASP.NET Core nếu trạng thái này kéo dài.';
      }
    }
  }

  function stopDemo() {
    if (demoTimer !== null) clearInterval(demoTimer);
    demoTimer = null;
    demoButton.innerHTML = '<span class="play-icon" aria-hidden="true">▶</span> Chạy thử dữ liệu';
    if (mqttConnected) setBrokerConnected(true);
    else if (syntheticSeen) state('demo', 'Dữ liệu mô phỏng');
    else state('offline', 'Chưa kết nối MQTT');
  }

  demoButton.addEventListener('click', () => {
    if (demoTimer !== null) { stopDemo(); return; }
    demoSend();
    demoTimer = setInterval(demoSend, 1800);
    demoButton.textContent = '■ Dừng mô phỏng';
  });

  el('resetButton').addEventListener('click', () => {
    stopDemo(); syntheticSeen = false; samples = []; count = 0;
    temperatureValue.textContent = '--'; humidityValue.textContent = '--';
    messageCount.textContent = '0'; lastUpdated.textContent = '--:--:--';
    historyCount.textContent = '0 bản tin';
    chartSource.previousElementSibling.textContent = '0 mẫu dữ liệu';
    chartSource.textContent = 'Nguồn dữ liệu: chưa có';
    rows.replaceChildren();
    const row = document.createElement('tr'); row.id = 'emptyHistory';
    const cell = document.createElement('td'); cell.colSpan = 4; cell.className = 'empty-row'; cell.textContent = 'Chưa có tin nhắn nào.';
    row.appendChild(cell); rows.appendChild(row); chartEmpty.hidden = false;
    notice.classList.remove('demo');
    if (mqttConnected) setBrokerConnected(true);
    else { noticeText.innerHTML = '<strong>Đang chờ kết nối MQTT.</strong> Chưa có dữ liệu mới.'; state('offline', 'Chưa kết nối MQTT'); }
    renderChart();
  });

  // SignalR events from ASP.NET Core call this API.
  window.MQTTDashboard = {
    receive: (topic, payload) => receive(topic, payload, 'mqtt'),
    setBrokerConnected
  };
  if (window.ResizeObserver) new ResizeObserver(renderChart).observe(chart);
  else window.addEventListener('resize', renderChart);
  renderChart();
})();
