'use strict';
(() => {
  const dashboard = () => window.MQTTDashboard;
  if (!window.signalR) {
    console.error('Could not load the official Microsoft SignalR client library');
    dashboard()?.setBrokerConnected(false);
    return;
  }

  const connection = new signalR.HubConnectionBuilder()
    .withUrl('/sensorHub')
    .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
    .build();

  connection.on('SensorMessage', (message) => {
    if (message && message.topic === 'device/data') {
      dashboard()?.receive(message.topic, message.payload);
    }
  });
  connection.on('MqttStatus', (connected) => {
    dashboard()?.setBrokerConnected(Boolean(connected));
  });
  connection.onreconnecting(() => dashboard()?.setBrokerConnected(false));
  connection.onclose(() => {
    dashboard()?.setBrokerConnected(false);
    window.setTimeout(start, 3000);
  });

  async function start() {
    if (connection.state !== signalR.HubConnectionState.Disconnected) return;
    try {
      await connection.start();
      const response = await fetch('/health', { cache: 'no-store' });
      if (response.ok) {
        const data = await response.json();
        dashboard()?.setBrokerConnected(Boolean(data.mqttConnected));
      }
    } catch (error) {
      dashboard()?.setBrokerConnected(false);
      console.warn('SignalR connection retrying:', error);
      window.setTimeout(start, 3000);
    }
  }
  start();
})();
