using Microsoft.AspNetCore.SignalR;
using MqttDashboard.Web.Services;

namespace MqttDashboard.Web.Hubs;

public sealed class SensorHub : Hub
{
    private readonly MqttConnectionState _mqtt;

    public SensorHub(MqttConnectionState mqtt) => _mqtt = mqtt;

    public override async Task OnConnectedAsync()
    {
        // Send current MQTT state to newly connected browsers.
        await Clients.Caller.SendAsync("MqttStatus", _mqtt.Connected);
        await base.OnConnectedAsync();
    }
}
