using Microsoft.AspNetCore.Mvc;

namespace MqttDashboard.Web.Controllers;

public sealed class HomeController : Controller
{
    public IActionResult Index() => View();

    [Route("Home/Error")]
    public IActionResult Error() => Content("Server error. Check: journalctl -u mqtt-aspnet -n 50");
}
