MQTT Dashboard - Static UI (Bước 13)

Các file:
  index.html - giao diện
  style.css - thiết kế responsive dark mode
  app.js - biểu đồ Canvas, hiển thị message và mô phỏng dữ liệu

Phiên bản này chỉ là giao diện. Không tự kết nối MQTT Broker.
Bấm 'Chạy thử dữ liệu' để tạo dữ liệu MÔ PHỎNG (được ghi nhãn rõ ràng).
Trong giai đoạn tiếp theo, tích hợp MQTT Broker qua WSS/WebSocket.

Kiểm tra sau khi triển khai:
  http://13.211.234.188 (IP có thể đổi nếu dừng/chạy lại EC2)
